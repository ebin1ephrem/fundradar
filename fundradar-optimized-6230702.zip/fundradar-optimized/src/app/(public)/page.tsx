import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, ShieldCheck, Timer, Waypoints } from "lucide-react";
import { search } from "@/lib/search";
import { homepageCategories, publicProviderCount } from "@/lib/queries/public";
import { OpportunityCard } from "@/components/public/opportunity-card";
import { SearchBar } from "@/components/public/search-bar";
import { Icon } from "@/components/admin/icon";
import { brand, home, search as searchCopy, seo, weeklySignal } from "@/content/copy";
import { JsonLd, organisationLd, websiteLd } from "@/components/public/structured-data";
import {
  CountUp,
  HeroOpportunitySignals,
  MaskedReveal,
  ParallaxLayer,
  RadarStrip,
  Reveal,
} from "@/components/public/motion";

const SITE = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  title: seo.home.title,
  description: seo.home.description,
  alternates: { canonical: "/" },
  openGraph: {
    title: seo.home.title,
    description: seo.home.description,
    url: "/",
    siteName: brand.lockup,
    type: "website",
  },
};

export const revalidate = 900;

export default async function HomePage() {
  const [categories, totals, closingSoon, recent, equityFree, largest] =
    await Promise.all([
      homepageCategories(),
      search.search({ perPage: 1 }),
      search.search({ closingWithinDays: 30, sort: "closing", perPage: 3 }),
      search.search({ sort: "newest", perPage: 3 }),
      search.search({ equityFreeOnly: true, perPage: 1 }),
      search.search({ sort: "largest", perPage: 1 }),
    ]);

  // Counts come from the database, never typed by hand.
  const categoryCounts = await search.facets(
    {},
    categories.map((c) => c.slug),
  );
  const providerCount = await publicProviderCount();

  const total = totals.total;

  return (
    <>
      <JsonLd data={organisationLd(SITE)} />
      <JsonLd data={websiteLd(SITE)} />

      {/* Hero ------------------------------------------------------------ */}
      <section className="relative overflow-hidden border-b border-line">
        <div
          className="dot-grid pointer-events-none absolute inset-0 opacity-[0.55]"
          aria-hidden="true"
        />
        <div className="page-shell relative grid gap-12 py-16 lg:py-28 xl:grid-cols-[minmax(0,1fr)_300px] xl:items-center">
          <div>
            <Reveal as="p" className="eyebrow" delay={0}>{home.hero.eyebrow}</Reveal>
            <h1 className="display-xl mt-4 max-w-[19ch]">
              <MaskedReveal delay={60}>{home.hero.headline}</MaskedReveal>
              <MaskedReveal className="text-muted" delay={145}>{home.hero.headlineSecond}</MaskedReveal>
            </h1>

            <Reveal as="p" className="lede mt-6 max-w-[58ch]" delay={235}>{home.hero.subline}</Reveal>

            <Reveal className="mt-9 max-w-[720px]" delay={330}>
              <SearchBar size="lg" />
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[13.5px] text-muted">
                <span>{home.search.chipsLabel}</span>
                {searchCopy.chips.map((item) => (
                  <Link key={item.href} href={item.href} className="underline underline-offset-[3px] transition-colors duration-200 hover:text-ink">
                    {item.label}
                  </Link>
                ))}
              </div>
            </Reveal>

            <Reveal delay={420}>
              <p className="mt-6 text-[13.5px] text-muted">{home.hero.supporting}</p>
              <dl className="mt-10 grid max-w-[640px] grid-cols-2 gap-x-8 gap-y-6 border-t border-line pt-8 sm:grid-cols-4">
                <Stat value={total} label="Opportunities" />
                <Stat value={providerCount} label="Providers" />
                <Stat value={equityFree.total} label="Equity-free" />
                <Stat value={closingSoon.total} label="Closing in 30 days" />
              </dl>
            </Reveal>
          </div>
          <HeroOpportunitySignals closing={closingSoon.hits[0]} recent={recent.hits[0]} />
        </div>
      </section>

      <RadarStrip closing={closingSoon.hits} recent={recent.hits} />

      {/* Categories ------------------------------------------------------ */}
      {categories.length ? (
        <section className="section-y border-b border-line">
          <div className="page-shell">
            <Reveal className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="eyebrow">{home.categories.eyebrow}</p>
                <h2 className="display-lg mt-2.5 max-w-[18ch]">
                  {home.categories.headline}
                </h2>
                <p className="lede mt-3 max-w-[48ch]">
                  {home.categories.subline}
                </p>
              </div>
              <Link href="/categories" className="btn btn-secondary">
                {home.categories.cta}
                <ArrowRight className="motion-arrow size-4" strokeWidth={1.8} />
              </Link>
            </Reveal>

            <Reveal variant="group" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  href={`/categories/${category.slug}`}
                  className="category-card group flex flex-col rounded-[12px] border border-line p-6"
                >
                  <span className="grid size-10 place-items-center rounded-[9px] bg-subtle transition-colors duration-200 group-hover:bg-accent">
                    <Icon name={category.icon} className="size-[18px]" />
                  </span>
                  <h3 className="mt-5 text-[18px] font-medium tracking-[-0.022em]">
                    {category.name}
                  </h3>
                  {category.description ? (
                    <p className="mt-2 line-clamp-2 text-[13.5px] leading-relaxed text-muted">
                      {category.description}
                    </p>
                  ) : null}
                  <p className="mt-5 flex items-center justify-between text-[13px] text-muted">
                    <span className="tabular-nums">
                      {(categoryCounts.get(category.slug) ?? 0).toLocaleString("en-IN")}{" "}
                      opportunities
                    </span>
                    <ArrowUpRight
                      className="motion-arrow size-4"
                      strokeWidth={1.7}
                      aria-hidden="true"
                    />
                  </p>
                </Link>
              ))}
            </Reveal>
          </div>
        </section>
      ) : null}

      {/* Closing soon ---------------------------------------------------- */}
      {closingSoon.hits.length ? (
        <section className="section-y">
          <div className="page-shell">
            <Header
              eyebrow={home.closing.eyebrow}
              title={home.closing.headline}
              description={home.closing.subline}
              href="/opportunities?closing=30"
              linkLabel={home.closing.cta}
            />
            <Reveal variant="group" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {closingSoon.hits.map((hit) => (
                <OpportunityCard key={hit.id} hit={hit} />
              ))}
            </Reveal>
          </div>
        </section>
      ) : null}

      {/* How it works ---------------------------------------------------- */}
      <section id="how-it-works" className="section-y border-t border-line">
        <div className="page-shell">
          <Reveal>
            <p className="eyebrow">{home.howItWorks.eyebrow}</p>
            <h2 className="display-lg mt-2.5 max-w-[16ch]">{home.howItWorks.headline}</h2>
          </Reveal>
          <Reveal as="ol" variant="group" stagger={80} className="mt-9 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {home.howItWorks.steps.map((step, i) => (
              <li
                key={step.title}
                className="how-step rounded-[12px] border border-line p-5"
              >
                <span className="how-step-number font-display text-[13px] font-medium tabular-nums text-muted transition-colors duration-200">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p className="mt-3 text-[15.5px] font-medium tracking-[-0.02em]">
                  {step.title}
                </p>
                <p className="mt-2 text-[13.5px] leading-relaxed text-muted">
                  {step.body}
                </p>
              </li>
            ))}
          </Reveal>
        </div>
      </section>

      {/* Founder story --------------------------------------------------- */}
      <section className="pb-4">
        <div className="page-shell-wide">
          <Reveal className="on-dark panel-dark relative overflow-hidden px-6 py-14 lg:px-16 lg:py-20">
            <ParallaxLayer className="dot-grid-dark pointer-events-none absolute -inset-y-8 inset-x-0 opacity-40" distance={18} />
            <div className="relative grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-start">
              <div>
                <p className="text-[11px] font-semibold tracking-[0.09em] text-on-dark-muted uppercase">
                  {home.trust.eyebrow}
                </p>
                <h2 className="display-lg mt-4 max-w-[16ch] text-on-dark">
                  {home.trust.headline}
                </h2>
                <p className="mt-5 max-w-[46ch] text-[15px] leading-relaxed text-on-dark-muted">
                  {home.trust.body}
                </p>
                <p className="mt-4 max-w-[46ch] text-[15px] leading-relaxed text-on-dark-muted">
                  {home.trust.body2}
                </p>
              </div>

              <Reveal variant="group" className="grid gap-3 sm:grid-cols-3">
                {home.trust.pillars.map((pillar, i) => (
                  <Pillar
                    key={pillar.title}
                    icon={[Waypoints, ShieldCheck, Timer][i]}
                    title={pillar.title}
                    body={pillar.body}
                  />
                ))}
              </Reveal>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Recently added -------------------------------------------------- */}
      {recent.hits.length ? (
        <section className="section-y">
          <div className="page-shell">
            <Header
              eyebrow={home.recent.eyebrow}
              title={home.recent.headline}
              description={home.recent.subline}
              href="/opportunities?sort=newest"
              linkLabel={home.recent.cta}
            />
            <Reveal variant="group" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {recent.hits.map((hit) => (
                <OpportunityCard key={hit.id} hit={hit} />
              ))}
            </Reveal>
          </div>
        </section>
      ) : null}

      {/* Quick routes ---------------------------------------------------- */}
      <section className="border-t border-line bg-subtle py-14 lg:py-20">
        <div className="page-shell">
          <Reveal>
            <h2 className="display-md">{home.open.headline}</h2>
            <p className="mt-2 text-[14.5px] text-muted">{home.open.subline}</p>
          </Reveal>
          <Reveal variant="group" className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Route
              href="/opportunities?provider=GOVERNMENT"
              title="Government grants"
              description="Central and state programmes for startups."
            />
            <Route
              href="/opportunities?equityFree=1"
              title="Equity-free funding"
              description={`${equityFree.total} programmes that take no equity.`}
            />
            <Route
              href="/opportunities?sort=largest"
              title="Largest funding"
              description={
                largest.hits[0]
                  ? `Up to ${largest.hits[0].fundingMax ? "₹" + Number(largest.hits[0].fundingMax).toLocaleString("en-IN") : "the largest amounts"}.`
                  : "The biggest amounts on offer."
              }
            />
            <Route
              href="/opportunities?closing=7"
              title="Closing this week"
              description="Deadlines in the next seven days."
            />
          </Reveal>
        </div>
      </section>

      {/* Weekly Radar / closing CTA -------------------------------------- */}
      <section className="border-t border-line py-14 lg:py-20">
        <Reveal className="page-shell grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:items-center">
          <div>
            <p className="eyebrow">{weeklySignal.eyebrow}</p>
            <h2 className="display-md mt-2.5 max-w-[18ch]">
              {home.banner.headline}
            </h2>
            <p className="lede mt-4 max-w-[48ch]">{home.banner.subline}</p>
            <p className="mt-4 max-w-[48ch] text-[14px] text-muted">
              {weeklySignal.supporting}
            </p>
          </div>
          <div className="rounded-[12px] border border-line bg-subtle p-7">
            <p className="text-[16px] font-medium tracking-[-0.02em]">
              {weeklySignal.headline}
            </p>
            <p className="mt-2 text-[14px] leading-relaxed text-muted">
              {weeklySignal.body2}
            </p>
            <Link href="/dashboard/alerts" className="btn btn-primary mt-5">
              {home.banner.cta}
              <ArrowRight className="motion-arrow size-4" strokeWidth={1.8} />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <dt className="sr-only">{label}</dt>
      <dd>
        <span className="block font-display text-[32px] leading-none font-medium tracking-[-0.035em] tabular-nums">
          <CountUp value={value} />
        </span>
        <span className="mt-1.5 block text-[13px] text-muted">{label}</span>
      </dd>
    </div>
  );
}

function Header({
  eyebrow,
  title,
  description,
  href,
  linkLabel,
}: {
  eyebrow: string;
  title: string;
  description: string;
  href: string;
  linkLabel: string;
}) {
  return (
    <Reveal className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="display-md mt-2.5">{title}</h2>
        <p className="mt-2 text-[14.5px] text-muted">{description}</p>
      </div>
      <Link href={href} className="text-[14px] text-muted underline underline-offset-2 hover:text-ink">
        {linkLabel}
      </Link>
    </Reveal>
  );
}

function Pillar({
  icon: IconCmp,
  title,
  body,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  body: string;
}) {
  return (
    <div className="rounded-[12px] border border-[rgba(255,255,255,0.08)] bg-ink-3 p-5 transition-transform duration-200 hover:-translate-y-0.5">
      <span className="grid size-8 place-items-center rounded-[7px] bg-accent text-ink">
        <IconCmp className="size-4" strokeWidth={1.7} />
      </span>
      <h3 className="mt-4 text-[15px] font-medium tracking-[-0.015em] text-on-dark">
        {title}
      </h3>
      <p className="mt-2 text-[13px] leading-relaxed text-on-dark-muted">{body}</p>
    </div>
  );
}

function Route({
  href,
  title,
  description,
}: {
  href: string;
  title: string;
  description: string;
}) {
  return (
    <Link
      href={href}
      className="route-card group rounded-[12px] border border-line bg-canvas p-5"
    >
      <p className="flex items-center justify-between text-[15.5px] font-medium tracking-[-0.02em]">
        {title}
        <ArrowUpRight
          className="motion-arrow size-4 text-faint"
          strokeWidth={1.7}
          aria-hidden="true"
        />
      </p>
      <p className="mt-1.5 text-[13.5px] text-muted">{description}</p>
    </Link>
  );
}
